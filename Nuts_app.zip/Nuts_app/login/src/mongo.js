const mongoose=require("mongoose")

mongoose.connect("mongodb://localhost:27017/LoginSignup")
.then(()=>{
  console.log("mongoose connected");
})
.catch((err)=>{
  console.log("failed to connect");
})

const LogInSchema=new mongoose.Schema({
  name:{
    type:String,
    required:true
  },
  password:{
    type:String,
    required:true
  }
})

const LogInCollection=new mongoose.model("LodInCollection", LogInSchema)

module.exports=LogInCollection